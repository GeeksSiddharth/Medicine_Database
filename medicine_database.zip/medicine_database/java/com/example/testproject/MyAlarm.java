package com.example.testproject;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.util.Log;
import android.widget.Toast;

import java.util.Locale;

//class extending the Broadcast Receiver
public class MyAlarm extends BroadcastReceiver {
    MediaPlayer mp;
    // fired when the alarm is triggerred
    @Override
    public void onReceive(Context context, Intent intent) {

        // doing anything
        // want to be done at a specific time everyday
        mp=MediaPlayer.create(context, R.raw.alarm1);
        mp.start();
        Toast.makeText(context, "Alarm....", Toast.LENGTH_LONG).show();
        //Log.d("MyAlarmBell", "Alarm just fire.....");
    }

}
